create trigger CWM2$CUBEDEL
    before delete
    on CWM2$CUBE
    for each row
declare
  begin
    delete from olapsys.CwM2$AWCubeLoad
      where Cube_IRID  = :old.irid
      and   Version_ID = 'CWM2';
    delete from olapsys.CwM2$AWCompositeSpec
      where Cube_IRID  = :old.irid
      and   Version_ID = 'CWM2';
    delete from olapsys.CwM2$AWCubeAgg
      where Cube_IRID  = :old.irid
      and   Version_ID = 'CWM2';
 end;
/

