create trigger CWM$MEASUREDEL
    before delete
    on CWM$MEASURE
    for each row
declare
  begin
    delete  from olapsys.CwM2$AWCubeLoadMeasure
      where IRID in (select  clm.IRID
                       from  CwM2$AWCubeLoad cl
                            ,CwM2$AWCubeLoadMeasure clm
                       where cl.IRID          = clm.CubeLoad_IRID
                       and   cl.Version_ID    = 'CWM'
                       and   clm.Measure_IRID = :old.irid);
  end;
/

