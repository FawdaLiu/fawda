create trigger CWM$LEVELDEL
    before delete
    on CWM$LEVEL
    for each row
declare
  begin
    delete  from olapsys.CwM2$AWCubeAggLevel
      where IRID in (select  cal.IRID
                       from  CwM2$AWCubeAgg ca
                            ,CwM2$AWCubeAggLevel cal
                       where ca.IRID        = cal.CubeAgg_IRID
                       and   ca.Version_ID  = 'CWM'
                       and   cal.Level_IRID = :old.irid);
  end;
/

