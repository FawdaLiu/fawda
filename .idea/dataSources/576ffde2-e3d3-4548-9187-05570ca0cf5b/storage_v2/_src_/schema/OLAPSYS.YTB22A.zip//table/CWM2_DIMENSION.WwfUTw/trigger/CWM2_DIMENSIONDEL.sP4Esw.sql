create trigger CWM2$DIMENSIONDEL
    before delete
    on CWM2$DIMENSION
    for each row
declare
  begin
    delete from olapsys.CwM2$AWDimLoad
      where Dim_IRID   = :old.irid
      and   Version_ID = 'CWM2';
    delete  from olapsys.CwM2$AWCompSpecMembership
      where IRID in (select  csm.IRID
                       from  CwM2$AWCompositeSpec cs
                            ,CwM2$AWCompSpecMembership csm
                       where cs.IRID       = csm.CompSpec_IRID
                       and   cs.Version_ID = 'CWM2'
                       and   csm.Dim_IRID  = :old.irid);
    delete  from olapsys.CwM2$AWCubeAggLevel
      where IRID in (select  cal.IRID
                       from  CwM2$AWCubeAgg ca
                            ,CwM2$AWCubeAggLevel cal
                       where ca.IRID       = cal.CubeAgg_IRID
                       and   ca.Version_ID = 'CWM2'
                       and   cal.Dim_IRID  = :old.irid);
  end;
/

