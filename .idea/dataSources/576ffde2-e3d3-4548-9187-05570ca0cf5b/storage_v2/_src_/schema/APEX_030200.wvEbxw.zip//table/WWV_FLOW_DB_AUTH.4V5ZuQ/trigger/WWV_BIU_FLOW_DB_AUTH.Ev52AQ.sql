create trigger WWV_BIU_FLOW_DB_AUTH
    before insert or update
    on WWV_FLOW_DB_AUTH
    for each row
begin
    :new.db_auth_schema := upper(:new.db_auth_schema);
end;
/

