create trigger OGIS_CRS_DELETE_TRIGGER
    before delete
    on OGIS_SPATIAL_REFERENCE_SYSTEMS
    for each row
BEGIN
  DELETE FROM MDSYS.sdo_coord_ref_system WHERE SRID = :old.srid;
END;
/

